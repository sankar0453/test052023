## addition code
def addition(a,b,c):
    print(a+b+c)
    return a+b+c

def multiplication(a,b):
    return a*b

def division(a,b):
    return a/b
